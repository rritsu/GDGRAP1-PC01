#include "Model3D.h"

Model3D::Model3D() {
    this->pos_x = 0.0f;
    this->pos_y = 0.0f;
    this->pos_z = 1.0f;
    this->scale_x = 1.0f;
    this->scale_y = 1.0f;
    this->scale_z = 1.0f;
    this->axis_x = 0.0f;
    this->axis_y = 1.0f;
    this->axis_z = 0.0f;
    this->theta = 0.0f;
}

//this behavior is for applying transformation and drawing the model
void Model3D::drawModel(std::vector<GLuint> mesh_indices, GLuint shaderProg, GLuint* VAO) {
    glm::mat4 transformation_matrix;
    transformation_matrix = glm::translate(glm::mat4(1.0f),
        glm::vec3(this->getPos_X(), this->getPos_Y(), this->getPos_Z())
    );

    transformation_matrix = glm::scale(transformation_matrix,
        glm::vec3(this->getScale_X(), this->getScale_Y(), this->getScale_Z())
    );

    transformation_matrix = glm::rotate(transformation_matrix,
        glm::radians(this->getTheta()),
        glm::normalize(glm::vec3(this->getAxis_X(), this->getAxis_Y(), this->getAxis_Z()))
    );
    
    glUseProgram(shaderProg);

    //transform
    unsigned int transformloc = glGetUniformLocation(shaderProg, "transform");
    glUniformMatrix4fv(transformloc, 1, GL_FALSE, glm::value_ptr(transformation_matrix));

    //draw
    glBindVertexArray(*VAO);
    glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);
}

void Model3D::setPosition(glm::vec3 newPos) {
    pos_x = newPos.x;
    pos_y = newPos.y;
    pos_z = newPos.z;
}

//GETTERS
//position
float Model3D::getPos_X() {
    return this->pos_x;
}

float Model3D::getPos_Y() {
    return this->pos_x;
}

float Model3D::getPos_Z() {
    return this->pos_z;
}

//SCALE
float Model3D::getScale_X() {
    return this->scale_x;
}

float Model3D::getScale_Y() {
    return this->scale_y;
}

float Model3D::getScale_Z() {
    return this->scale_z;
}

//AXIS
float Model3D::getAxis_X() {
    return this->axis_x;
}

float Model3D::getAxis_Y() {
    return this->axis_y;
}

float Model3D::getAxis_Z() {
    return this->axis_z;
}

//THETA
float Model3D::getTheta() {
    return this->theta;
}
