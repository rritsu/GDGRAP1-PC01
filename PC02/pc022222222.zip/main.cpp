/*
GDGRAP1 - PC2
Date: 03-22-24
Group 5 Members:
    Austria, Joshua Angelo E.
    Legaspi, Andrea Maxene F.
*/

#include <iostream>
#include <string>
#include <vector>
#include <chrono>

//class header
#include "Model3D.h"
#include "Light/Light.h"
#include "Light/PointLight.h"
#include "Light/DirectionLight.h"
#include "Camera/MyCamera.h"
#include "Camera/OrthoCamera.h"
#include "Camera/PerspectiveCamera.h"


//openGL
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//obj loader
#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

float width = 800.0f;
float height = 800.0f;

//timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

bool firstMouse = true;
std::string projectionType = "Perspective";

//Model3D* model;
Model3D* model = new Model3D();
Model3D* lightSource = new Model3D();
Model3D* activeModel = new Model3D();

MyCamera* Camera = new MyCamera();

PointLight* lightsource = new PointLight();

std::vector<Model3D*> vecModels;
//glm::vec3 lastCameraPos = glm::vec3(1.0f);
// glm::vec3 lastCameraFront = glm::vec3(1.0f);
//glm::vec3 lastCameraUp = glm::vec3(1.0f);

int i = 1;
double last_xpos = 0.0f;
double last_ypos = 0.0f;


int modelInt = 1;  //1 for the model, 2 for the lightsource
int modelLP = 2;


//this function handles the mouse control for the camera
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    /*
    Camera->initialize(&firstMouse, xpos, ypos);
    if (projectionType == "Perspective") {
        if (i == 0) {
            xpos = last_xpos;
            ypos = last_ypos;
            std::cout << "hello" << std::endl;
        }
        i++;
        Camera->updateMouse(xpos, ypos);
        std::cout << "wah" << std::endl;
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }
    */
    Camera->initialize(&firstMouse, xpos, ypos);
    if (projectionType == "Perspective") {
        Camera->updateMouse(xpos, ypos);
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }

}



void processInput(GLFWwindow* window)
{
    //float cameraSpeed = 2.5 * deltaTime;

    switch (modelInt) {
    case 1:
        activeModel = model;
        break;
    case 2:
        activeModel = lightSource;
        break;
    }


    float theta_x = activeModel->getTheta_X();
    float theta_y = activeModel->getTheta_Y();
    float theta_z = activeModel->getTheta_Z();

    float pos_x = activeModel->getPos_X();
    float pos_y = activeModel->getPos_Y();
    float pos_z = activeModel->getPos_Z();

    //---------ROTATION----------
    //x-axis
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            activeModel->setTheta_X(theta_x + 0.03f);

    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        activeModel->setTheta_X(theta_x - 0.03f);
    }

    //y-axis
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        activeModel->setTheta_Y(theta_y - 0.03f);
    }

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        activeModel->setTheta_Y(theta_y + 0.03f);
    }

    //z-axis
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        activeModel->setTheta_Z(theta_z + 0.03f);
    }

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        activeModel->setTheta_Z(theta_z - 0.03f);
    }

}



void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode) {

    //  glm::vec3 lasCameraPos = Camera.getCameraPos();
    //  glm::vec3 lastCameraFront = Camera.getCameraFront();
     // glm::vec3 lastCameraUp = Camera.getCameraUp();

      //-------EXIT BUTTON-----------
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    //-------SWAP OBJECTS----------
    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        if (modelInt == 1)
            modelInt = 2;

        else
            modelLP = 2;

        std::cout << "Swapped active model" << std::endl;
    }

    if (key == GLFW_KEY_1 && action == GLFW_PRESS) {
        if (projectionType == "Perspective")
            std::cout << "Already using perspective projection" << std::endl;
        else {
            //Camera->setCameraPos(lastCameraPos);
            //Camera->setCameraFront(lastCameraFront);
            projectionType = "Perspective";
            i = 0;
            std::cout << "Changed projection type" << std::endl;
        }
    }

    if (key == GLFW_KEY_2 && action == GLFW_PRESS) {
        if (projectionType == "Ortho")
            std::cout << "Already using ortho projection" << std::endl;
        else {
            //lastCameraPos = Camera->getCameraPos();
            //lastCameraFront = Camera->getCameraFront();
            //lastCameraUp = Camera.getCameraUp();
            projectionType = "Ortho";
            i = 1;
            std::cout << "Changed projection type" << std::endl;
        }
    }
}


int main(void) {
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Legaspi,Andrea and Austria,Joshua", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    //mouse callbacks
    glfwSetCursorPosCallback(window, mouse_callback);
    // glfwSetKeyCallback(window, Key_Callback);
    // glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //shaders
    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;
    vertBuff << vertSrc.rdbuf();
    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();

    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;
    fragBuff << fragSrc.rdbuf();
    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();

    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0, 0, width, height);

    //create and links shader
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &v, NULL);
    glCompileShader(vertexShader);

    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, &f, NULL);
    glCompileShader(fragShader);

    GLuint shaderProg = glCreateProgram();
    glAttachShader(shaderProg, vertexShader);
    glAttachShader(shaderProg, fragShader);

    glLinkProgram(shaderProg);

    //load texture
    int img_width, img_height, colorChannels;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* tex_bytes = stbi_load("3D/airGun.jpg", &img_width, &img_height, &colorChannels, 0);

    GLuint texture;
    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img_width, img_height, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_bytes);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(tex_bytes);

    glEnable(GL_DEPTH_TEST);


    //loads the 3D model
    //source: https://free3d.com/3d-model/gun-54829.html
    std::string path = "3D/airGun.obj";
    std::vector <tinyobj::shape_t> shapes;
    std::vector <tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;

    bool success = tinyobj::LoadObj(&attributes, &shapes, &material, &warning, &error, path.c_str());

    std::vector<GLfloat> fullVertexData;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++) {
        tinyobj::index_t vData = shapes[0].mesh.indices[i];

        //vertices
        fullVertexData.push_back(attributes.vertices[(vData.vertex_index * 3)]);
        fullVertexData.push_back(attributes.vertices[(vData.vertex_index * 3 + 1)]);
        fullVertexData.push_back(attributes.vertices[(vData.vertex_index * 3 + 2)]);

        //normals
        fullVertexData.push_back(attributes.normals[(vData.normal_index * 3)]);
        fullVertexData.push_back(attributes.normals[(vData.normal_index * 3 + 1)]);
        fullVertexData.push_back(attributes.normals[(vData.normal_index * 3 + 2)]);

        //UVs
        fullVertexData.push_back(attributes.texcoords[(vData.texcoord_index * 2)]);
        fullVertexData.push_back(attributes.texcoords[(vData.texcoord_index * 2 + 1)]);
    }
    //OLD
        /*
        std::vector<GLuint> mesh_indices;
        for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
        {
            mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
        }*/

        //buffers
    GLuint VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GL_FLOAT) * fullVertexData.size(), fullVertexData.data(), GL_DYNAMIC_DRAW);

    //vertices
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    //normals
    GLintptr normalPtr = 3 * sizeof(float);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)normalPtr);
    glEnableVertexAttribArray(1);

    GLintptr uvPtr = 6 * sizeof(float);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)uvPtr);
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * mesh_indices.size(), &mesh_indices[0], GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    //loads the 3D model
//source: https://free3d.com/3d-model/gun-54829.html
    std::string path1 = "3D/smallball.obj";
    std::vector <tinyobj::shape_t> shapes1;
    std::vector <tinyobj::material_t> material1;
    std::string warning1, error1;

    tinyobj::attrib_t attributes1;

    bool success1 = tinyobj::LoadObj(&attributes1, &shapes1, &material1, &warning1, &error1, path1.c_str());

    std::vector<GLuint> mesh_indices1;
    for (int i = 0; i < shapes1[0].mesh.indices.size(); i++)
    {
        mesh_indices1.push_back(shapes1[0].mesh.indices[i].vertex_index);
    }
    //OLD
        /*
        std::vector<GLuint> mesh_indices;
        for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
        {
            mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
        }*/

        //buffers
    GLuint sphereVAO, sphereVBO, sphereEBO;
    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1, &sphereVBO);
    glGenBuffers(1, &sphereEBO);

    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GL_FLOAT) * attributes1.vertices.size(), &attributes1.vertices[0], GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * mesh_indices1.size(), &mesh_indices1[0], GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    std::cout << "Press [ESCAPE] key to exit" << std::endl;

    PointLight pointLight;
    //spawn model on run
 //   spawnModel();

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //per-frame time logic
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        //input
        processInput(window);
        glfwSetKeyCallback(window, Key_Callback);

        glClear(GL_COLOR_BUFFER_BIT);

        glm::mat4 view = glm::mat4(1.0f);
        glm::mat4 projection = glm::mat4(1.0f);

        //this->cameraPos, this->cameraPos + this->cameraFront, this->cameraUp


        if (projectionType == "Perspective") {
            PerspectiveCamera perspective;
            projection = perspective.giveProjection(width, height);
            Camera->bindProjection(shaderProg, projection);
            Camera->bindView(shaderProg);
        }
        else if (projectionType == "Ortho") {
            OrthoCamera ortho;
            projection = ortho.giveProjection();
            Camera->bindProjection(shaderProg, projection);
            ortho.bindView(shaderProg);
            //implement smth that will retain old mouse's position when changing back to perspective
        }

        glm::vec3 lightPosition = lightSource->getPosition();
        pointLight.setLightPoint(lightPosition);


        DirectionLight dirLight;
        dirLight.bindLightDirection(shaderProg);

        Light light;
        light.bindLighting(shaderProg);


        //draw the models
        model->drawModel(fullVertexData, texture, shaderProg, &VAO, 8);

        //draw(?) lightsource below 

        lightSource->setPosition(glm::vec3(.0f, .0f, .0f));
        lightSource->drawLightPoint(mesh_indices1, shaderProg, &sphereVAO);
        pointLight.bindLightPoint(shaderProg);

        //swap front and back buffers 
        glfwSwapBuffers(window);

        // Poll for and process events 
        glfwPollEvents();
    }

    //delete buffers
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    // glDeleteBuffers(1, &EBO);

    glfwTerminate();

    return 0;
}