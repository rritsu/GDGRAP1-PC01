#pragma once

#include "Light.h"
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

class PointLight
{
	private:
		glm::vec3 lightPoint;

	public:
		PointLight();

	public:
		void bindLightPoint(GLuint shaderProg);

	public:
		void setLightPoint(glm::vec3 lightDirection);
		void setLightPoint_X(float point_x);
		void setLightPoint_Y(float point_y);
		void setLightPoint_Z(float point_z);
};

