/*
GDGRAP1 - MP
Date: 04-07-24
Group 5 Members:
    Austria, Joshua Angelo E.
    Legaspi, Andrea Maxene F.
*/

#include <iostream>
#include <string>
#include <vector>
#include <chrono>

//class header
#include "Model3D.h"
#include "Shader.h"
#include "Skybox.h"
#include "Light/Light.h"
#include "Light/PointLight.h"
#include "Light/DirectionLight.h"
#include "Camera/MyCamera.h"
#include "Camera/OrthoCamera.h"
#include "Camera/PerspectiveCamera.h"

//openGL
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//obj loader
#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


float width = 800.0f;
float height = 800.0f;

//timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

bool firstMouse = true;
std::string projectionType = "Perspective";
std::string POV = "Third Person";
std::string lastPOV = "Third Person";

//Model3D* model;
Model3D* psub = new Model3D();
Model3D* esub1 = new Model3D();
Model3D* esub2 = new Model3D();
Model3D* esub3 = new Model3D();
Model3D* esub4 = new Model3D();
Model3D* esub5 = new Model3D();
Model3D* esub6 = new Model3D();
Model3D* lightSource = new Model3D();
Model3D* activeModel = new Model3D();

//MyCamera* Camera = new MyCamera();
PerspectiveCamera* persCamera = new PerspectiveCamera();
OrthoCamera* orthoCamera = new OrthoCamera();

PointLight* pointLight = new PointLight();
DirectionLight* directionLight = new DirectionLight();

int i = 1;
double last_xpos = 2630.0f;
double last_ypos = 510.0f;


int modelInt = 1;  //1 for the model, 2 for the lightsource
int modelLP = 2;


//this function handles the mouse control for the camera
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    /*
    Camera->initialize(&firstMouse, xpos, ypos);
    if (projectionType == "Perspective") {
        if (i == 0) {
            xpos = last_xpos;
            ypos = last_ypos;
            std::cout << "hello" << std::endl;
        }
        i++;
        Camera->updateMouse(xpos, ypos);
        std::cout << "wah" << std::endl;
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }
    */

    persCamera->initialize(&firstMouse, xpos, ypos);

 //   camera->setCameraPos(glm::vec3())

    if (projectionType == "Perspective" && POV == "Third Person") {
       // Camera->updateMouse(xpos, ypos);
        persCamera->updateMouse(xpos, ypos); //<<--currently perspective (not specified if first person or thirdd
       // std::cout << "x: " << xpos << std::endl;
       // std::cout << "y: " << ypos << std::endl;
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }

}



void processInput(GLFWwindow* window)
{
  //  float cameraSpeed = 5 * deltaTime;
    int type = 0;

    if (POV == "Third Person") {
        type = 1;
    }
    else {
        type = 2;
    }

    float pos_x = psub->getPos_X();
    float pos_y = psub->getPos_Y();
    float pos_z = psub->getPos_Z();

    //-----------WASDQE MOVEMENT------------

    //FORWARD
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        psub->setPos_Z(pos_z - 0.1f);
        psub->setTheta_Y(0.0f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);

    }

    //BACKWARD
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        psub->setPos_Z(pos_z + 0.1f);
        psub->setTheta_Y(180.0f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);
    }

    //LEFT
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        psub->setPos_X(pos_x - 0.1f);
        psub->setTheta_Y(270.0f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);
    }

    //RIGHT
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        psub->setPos_X(pos_x + 0.1f);
        psub->setTheta_Y(90.0f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);
      //  camera->setCameraPos(glm::vec3(pos_x, pos_y + 0.3f, pos_z + 1.15f));
    }

    //DESCEND
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        psub->setPos_Y(pos_y - 0.1f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);
      //  camera->setCameraPos(glm::vec3(pos_x, pos_y + 0.3f, pos_z + 1.15f));
    }

    //ASCENDD
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        psub->setPos_Y(pos_y + 0.1f);
        persCamera->updatePosition(type, pos_x, pos_y, pos_z);
       // camera->setCameraPos(glm::vec3(pos_x, pos_y + 0.3f, pos_z + 1.15f));
    }

}




void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode) {

    //  glm::vec3 lasCameraPos = Camera.getCameraPos();
    //  glm::vec3 lastCameraFront = Camera.getCameraFront();
     // glm::vec3 lastCameraUp = Camera.getCameraUp();

      //-------EXIT BUTTON-----------
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);


    float pos_x = psub->getPos_X();
    float pos_y = psub->getPos_Y();
    float pos_z = psub->getPos_Z();

    if (key == GLFW_KEY_1 && action == GLFW_PRESS) {
       // if (projectionType == "Perspective") {

            if (POV == "Third Person") {
                std::cout << "Changed to First Person POV" << std::endl;
                POV = "First Person";
                projectionType = "Perspective";
                persCamera->setCameraPos(glm::vec3(pos_x, pos_y, pos_z - 4.0f));
                lastPOV = "First Person";
            }

            else if (POV == "First Person") {
                POV = "Third Person";
                i = 0;
                std::cout << "Changed to Third Person POV" << std::endl;
                projectionType = "Perspective";
                persCamera->setCameraPos(glm::vec3(pos_x, pos_y + 0.3f, pos_z + 1.15f));
                lastPOV = "Third Person";
            }
       // }
    }

    if (key == GLFW_KEY_2 && action == GLFW_PRESS) {
        if (projectionType == "Ortho") {
            std::cout << "Already using ortho projection" << std::endl; 
        }
        else {
            projectionType = "Ortho";
            std::cout << "Changed projection type" << std::endl; 
            
        }
    }
}


int main(void) {
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Legaspi,Andrea and Austria,Joshua", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    //mouse callbacks
    glfwSetCursorPosCallback(window, mouse_callback);
  //  glfwSetCursor(window, )
    
    // glfwSetKeyCallback(window, Key_Callback);
    // glfwSetScrollCallback(window, scroll_callback);

  //  glfwSetCursorPosCallback(window, cursor_position_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0, 0, width, height);


    //STORE MODELS INTO A VECTOR
    std::vector <Model3D*> vecModels;
    vecModels.push_back(psub);
    vecModels.push_back(esub1);
    vecModels.push_back(esub2);
    vecModels.push_back(esub3);
    vecModels.push_back(esub4);
    vecModels.push_back(esub5);
    vecModels.push_back(esub6);


    //-------------LIGHTING-----------------
    directionLight->setUpProperties();


    //--------------SHADER------------------
    Shader* shader = new Shader();
    GLuint shaderProg = shader->createShader("Shaders/model.vert", "Shaders/model.frag");
    glLinkProgram(shaderProg);
    shader->deleteShader();
    


    //--------------PLAYER------------------
    //source: https://www.turbosquid.com/3d-models/3d-titan-submersible-2087088
    //LOAD TEXTURE AND NORMAL MAPS
    GLuint ptexture = psub->loadTexture(1, 1, "3D/player/player_base.png");
    GLuint pNorm_tex = psub->loadNormalMap(1, 1, "3D/player/player_normal.png");

    //VERTEX DATA
    std::vector<GLfloat> pfullVertexData = psub->loadModel("3D/player/player.obj");
  
    //BIND BUFFERS   
    GLuint pVAO, pVBO;
    psub->bindBuffers(pfullVertexData, &pVAO, &pVBO);
    std::cout << "player model loaded" << std::endl;

  

    //--------------ENEMY 1-----------------
    //source: https://www.cgtrader.com/free-3d-models/military/military-vehicle/submarine-0a98eb1b-a71d-45b9-8ed6-66640987efb6
    GLuint e1texture = esub1->loadTexture(1, 1, "3D/enemy1/enemy1_base.jpg");
    GLuint e1Norm_tex = esub1->loadNormalMap(1, 2, "3D/enemy1/enemy1_normal.png");
    std::vector<GLfloat> e1fullVertexData = esub1->loadModel("3D/enemy1/enemy1.obj");

    GLuint e1VAO, e1VBO;
    esub1->bindBuffers(e1fullVertexData, &e1VAO, &e1VBO);
    std::cout << "enemy1 model loaded" << std::endl;


 
    //--------------ENEMY 2-----------------
    //source: https://www.cgtrader.com/3d-model/bathyscaphe-c
    GLuint e2texture = esub2->loadTexture(1, 1, "3D/enemy2/enemy2_base.png");
    GLuint e2Norm_tex = esub2->loadNormalMap(1, 2, "3D/enemy2/enemy2_normal.png");
    std::vector<GLfloat> e2fullVertexData = esub2->loadModel("3D/enemy2/enemy2.obj");

    GLuint e2VAO, e2VBO;
    esub2->bindBuffers(e2fullVertexData, &e2VAO, &e2VBO);
    std::cout << "enemy2 model loaded" << std::endl;



    //--------------ENEMY 3-----------------
    //souce: https://www.cgtrader.com/3d-model/fantastic-boat
    GLuint e3texture = esub3->loadTexture(1, 1, "3D/enemy3/enemy3_base.png");
    GLuint e3Norm_tex = esub3->loadNormalMap(1, 1, "3D/enemy3/enemy3_normal.png");
    std::vector<GLfloat> e3fullVertexData = esub3->loadModel("3D/enemy3/enemy3.obj");

    GLuint e3VAO, e3VBO;
    esub3->bindBuffers(e3fullVertexData, &e3VAO, &e3VBO);
    std::cout << "enemy3 model loaded" << std::endl;



    //--------------ENEMY 4-----------------
    //souce: 
    GLuint e4texture = esub4->loadTexture(1, 1, "3D/enemy4/enemy4_base.png");
    GLuint e4Norm_tex = esub4->loadNormalMap(1, 2, "3D/enemy4/enemy4_normal.png");
    std::vector<GLfloat> e4fullVertexData = esub4->loadModel("3D/enemy4/enemy4.obj");

    GLuint e4VAO, e4VBO;
    esub4->bindBuffers(e4fullVertexData, &e4VAO, &e4VBO);
    std::cout << "enemy4 model loaded" << std::endl;




    //--------------ENEMY 5-----------------
    //source: https://github.com/ThiagoPereiraUFV/Submarine-Simulator/blob/master/models/submarine.obj
    //https://github.com/ThiagoPereiraUFV/Submarine-Simulator/blob/master/models/texture/ship.bmp 
    GLuint e5texture = esub5->loadTexture(1, 1, "3D/enemy5/enemy5_base.png");
    GLuint e5Norm_tex = esub5->loadNormalMap(1, 2, "3D/enemy5/enemy5_normal.png");
    std::vector<GLfloat> e5fullVertexData = esub5->loadModel("3D/enemy5/enemy5.obj");

    GLuint e5VAO, e5VBO;
    esub5->bindBuffers(e5fullVertexData, &e5VAO, &e5VBO);
    std::cout << "enemy5 model loaded" << std::endl;
   
 

    //--------------ENEMY 6-----------------
    //source: https://free3d.com/3d-model/tugboat-v1--395993.html
    GLuint e6texture = esub6->loadTexture(1, 1, "3D/enemy6/enemy6_base.png");
    GLuint e6Norm_tex = esub6->loadNormalMap(1, 1, "3D/enemy6/enemy6_normal.png");
    std::vector<GLfloat> e6fullVertexData = esub6->loadModel("3D/enemy6/enemy6.obj");

    GLuint e6VAO, e6VBO;
    esub6->bindBuffers(e6fullVertexData, &e6VAO, &e6VBO);
    std::cout << "enemy6 model loaded" << std::endl;
    

    //--------------SKYBOX------------------
    Shader* skybox_shader = new Shader();
    GLuint skybox_shaderProg = skybox_shader->createShader("Shaders/sky.vert", "Shaders/sky.frag");
    glLinkProgram(skybox_shaderProg);
    skybox_shader->deleteShader();

    Skybox* skybox = new Skybox();

    unsigned int skyboxVAO;
    skybox->bindBuffers(&skyboxVAO);

    std::string facesSkybox[]{
        "Skybox/ocean_rt.png",
        "Skybox/ocean_lf.png",
        "Skybox/ocean_up.png",
        "Skybox/ocean_dn.png",
        "Skybox/ocean_ft.png",
        "Skybox/ocean_bk.png"
    };

    unsigned int skyboxTex = skybox->initializeCubeMap(facesSkybox);



   // PointLight pointLight;
    //spawn model on run
 //   spawnModel();a



    //BLENDING
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, //source factor
        GL_ONE_MINUS_SRC_ALPHA); //destination factor)



    //INITIALIZE PLAYER POSITION
    psub->setScale(glm::vec3(0.1f, 0.1f, 0.1f));
    psub->setTheta_Y(180.0f);
    psub->setPosition(glm::vec3(0.0f, 0.0f, 1.0f));
    persCamera->setCameraPos(glm::vec3(0.0f, psub->getPos_Y() + 0.3f, psub->getPos_Z() + 1.15f));



    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //per-frame time logic
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        //input
        processInput(window);
        glfwSetKeyCallback(window, Key_Callback);

        glm::mat4 viewMatrix = glm::mat4(1.0f);
        glm::mat4 projection = glm::mat4(1.0f);

        int type = 0;

        if (projectionType == "Perspective") {
            type = 1;
            //THIRD PERSON POV
            if (POV == "Third Person") {
                projection = persCamera->giveProjection(width, height);
                viewMatrix = persCamera->giveView(1);
            }

            //FIRST PERSON POV
            else {
                projection = persCamera->giveProjection(width, height);
                viewMatrix = persCamera->giveView(1);
               // camera->setCameraCenter()
            }
        }
        else if (projectionType == "Ortho") {
            type = 2;
            projection = orthoCamera->giveProjection();
           // viewMatrix = persCamera->giveView(1);
        }


        //--------------DRAW SKYBOX---------------
        skybox->drawSkybox(type, skybox_shaderProg, &skyboxVAO, viewMatrix, projection, skyboxTex);


        glm::vec3 cameraPos = persCamera->getCameraPos();

      //  glm::vec3 cameraPos = Camera->getCameraPos();


        //get lightpos, lightcolor, , ambientstr, ambientColor, specStr, brightness, specPhong

        //GENERAL LIGHT PROPERTIES
        glm::vec3 lightColor = directionLight->getLightColor();
        glm::vec3 ambientColor = directionLight->getAmbientColor();


        //DIRECTION LIGHT PROPERTIES
        glm::vec3 lightDirection = directionLight->getLightDirection();
        glm::vec3 dir_lightPos = directionLight->getLightPos();
        float dir_brightness = directionLight->getBrightness();
        float dir_ambientStr = directionLight->getAmbientStr();
        float dir_specStr = directionLight->getSpecStr();
        float dir_specPhong = directionLight->getSpecPhong();

        /*  
        PointLight* pointLight = new PointLight();
        glm::vec3 point_lightPos = pointLight->getLightPos();
        float point_brightness = pointLight->getBrightness();
        float point_specStr = pointLight->getSpecStr();
        float point_specPhong = pointLight->getSpecPhong();
        */

      //  glm::vec3 point_LightPos = pointLight->getLightPos();
       // float point_brightness = pointLight->


        for (int i = 0; i < vecModels.size(); i++) {
            glUseProgram(shaderProg);

            vecModels[i]->bindCamera(shaderProg, projection, viewMatrix, cameraPos);

            //DIRECTION LIGHT
            vecModels[i]->bindLight(shaderProg, dir_lightPos, lightColor, dir_brightness, "dir_lightPos", "dir_brightness");
            vecModels[i]->bindAmbient(shaderProg, dir_ambientStr, ambientColor, "dir_ambientStr");
            vecModels[i]->bindSpec(shaderProg, dir_specStr, dir_specPhong, "dir_specStr", "dir_specPhong");
            vecModels[i]->bindLightDirection(shaderProg, lightDirection);

          //  dir_ambientStr, ambientColor, dir_specStr, , dir_specPhong);
        }



        //LIGHTING
      //  directionLight->setLightPos(glm::vec3(0.0, 5.0f, 1.0f));
       // directionLight->setUpProperties();
        //directionLight->bindLightDirection(shaderProg);
      //  directionLight->bindLighting(shaderProg);




        glm::vec3 lightPosition = lightSource->getPosition();
      //d  pointLight.setLightPoint(lightPosition);
     //   DirectionLight dirLight;
       // dirLight.bindLightDirection(psub_shaderProg);

     //   Light light;
     //   light.bindLighting(psub_shaderProg);

    //    pointLight.bindLightPoint(lshaderProg);

        int numVertices = 14;

        //--------------DRAW MODELS---------------
        psub->drawModel(pfullVertexData, ptexture, pNorm_tex, shaderProg, &pVAO, numVertices);

        
        esub1->setScale(glm::vec3(0.5f, 0.5f, 0.5f));
        esub1->setPosition(glm::vec3(15.0f, 0.0f, -30.0f));
        esub1->drawModel(e1fullVertexData, e1texture, e1Norm_tex, shaderProg, &e1VAO, numVertices);
       
        esub2->setScale(glm::vec3(1.5f, 1.5f, 1.5f));
        esub2->setPosition(glm::vec3(-14.5f, -0.5f, -30.0f));
        esub2->drawModel(e2fullVertexData, e2texture, e2Norm_tex, shaderProg, &e2VAO, numVertices);
      
        esub3->setScale(glm::vec3(0.7f, 0.7f, 0.7f));
        esub3->setPosition(glm::vec3(-10.2f, -0.2f, -10.0f));
        esub3->drawModel(e3fullVertexData, e3texture, e3Norm_tex, shaderProg, &e3VAO, numVertices);

        esub4->setScale(glm::vec3(0.1f, 0.1f, 0.1f));
        esub4->setPosition(glm::vec3(50.8f, -0.8f, -50.8f));
        esub4->drawModel(e4fullVertexData, e4texture, e4Norm_tex, shaderProg, &e4VAO, numVertices);
         
        esub5->setScale(glm::vec3(0.09f, 0.09f, 0.09f));
        esub5->setPosition(glm::vec3(-50.8f, 0.8f, -40.0f));
        esub5->drawModel(e5fullVertexData, e5texture, e5Norm_tex, shaderProg, &e5VAO, numVertices);

        esub6->setScale(glm::vec3(0.9f, .9f, 0.9f));
        esub6->setPosition(glm::vec3(1.4f, -0.4f, -50.f));
        esub6->drawModel(e6fullVertexData, e6texture, e6Norm_tex, shaderProg, &e6VAO, numVertices);

        

        //swap front and back buffers 
        glfwSwapBuffers(window);

        // Poll for and process events 
        glfwPollEvents();
    }

    //--------------DELETE BUFFERS---------------
    glDeleteVertexArrays(1, &pVAO);
    glDeleteBuffers(1, &pVBO);
    
   
    glDeleteVertexArrays(1, &e1VAO);
    glDeleteBuffers(1, &e1VBO);

    glDeleteVertexArrays(1, &e2VAO);
    glDeleteBuffers(1, &e2VBO);

    glDeleteVertexArrays(1, &e3VAO);
    glDeleteBuffers(1, &e3VBO);

    glDeleteVertexArrays(1, &e4VAO);
    glDeleteBuffers(1, &e4VBO);
 

    glDeleteVertexArrays(1, &e5VAO);
    glDeleteBuffers(1, &e5VBO);

    glDeleteVertexArrays(1, &e6VAO);
    glDeleteBuffers(1, &e6VBO);

    
    glfwTerminate();

    return 0;
}