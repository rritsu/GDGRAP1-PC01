/*
GDGRAP1 - MP
Date: 04-07-24
Group 5 Members:
    Austria, Joshua Angelo E.
    Legaspi, Andrea Maxene F.
*/

#include <iostream>
#include <string>
#include <vector>
#include <chrono>

//class header
#include "Model3D.h"
#include "Shader.h"
#include "Skybox.h"
#include "Light/Light.h"
#include "Light/PointLight.h"
#include "Light/DirectionLight.h"
#include "Camera/MyCamera.h"
#include "Camera/OrthoCamera.h"
#include "Camera/PerspectiveCamera.h"

//openGL
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//obj loader
#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


float width = 800.0f;
float height = 800.0f;

//timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

bool firstMouse = true;
std::string projectionType = "Perspective";

//Model3D* model;
Model3D* psub = new Model3D();
Model3D* esub1 = new Model3D();
Model3D* esub2 = new Model3D();
Model3D* esub3 = new Model3D();
Model3D* esub4 = new Model3D();
Model3D* esub5 = new Model3D();
Model3D* esub6 = new Model3D();
Model3D* lightSource = new Model3D();
Model3D* activeModel = new Model3D();

MyCamera* Camera = new MyCamera();

PointLight* lightsource = new PointLight();

DirectionLight* directionLight = new DirectionLight();

int i = 1;
double last_xpos = 0.0f;
double last_ypos = 0.0f;


int modelInt = 1;  //1 for the model, 2 for the lightsource
int modelLP = 2;


//this function handles the mouse control for the camera
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    /*
    Camera->initialize(&firstMouse, xpos, ypos);
    if (projectionType == "Perspective") {
        if (i == 0) {
            xpos = last_xpos;
            ypos = last_ypos;
            std::cout << "hello" << std::endl;
        }
        i++;
        Camera->updateMouse(xpos, ypos);
        std::cout << "wah" << std::endl;
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }
    */
    Camera->initialize(&firstMouse, xpos, ypos);
    if (projectionType == "Perspective") {
        Camera->updateMouse(xpos, ypos);
    }
    else {
        if (i == 1) {
            last_xpos = xpos;
            last_ypos = ypos;
        }
        i++;
    }

}



void processInput(GLFWwindow* window)
{
    //float cameraSpeed = 2.5 * deltaTime;

    switch (modelInt) {
    case 1:
        activeModel = psub;
        break;
    case 2:
        activeModel = lightSource;
        break;
    }


  //  float theta_x = activeModel->getTheta_X();
   // float theta_y = activeModel->getTheta_Y();
   // float theta_z = activeModel->getTheta_Z();

    float pos_x = activeModel->getPos_X();
    float pos_y = psub->getPos_Y();
   // float pos_z = activeModel->getPos_Z();
     
    /*
    //---------ROTATION----------
    //x-axis
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        psub->setPos_Y(pos_y - 0.0003f);
        Camera->setCam_X(Camera->getCam_X() - 0.3f);
      //  activeModel->setPos_Y(pos_y - 0.03f);
      //  pos_y -= 0.03f;
       // psub->setAxis_Y(pos_y);
        std::cout << "Depth at: " << psub->getPos_Y() << std::endl;
       // activeModel->setPos_X(pos_x - 0.003f);

    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
      //  activeModel->setPos_Y(pos_y + 0.03f);
   //     std::cout << "Depth at: " << pos_y << std::endl;
    }

    //y-axis
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
     //   activeModel->setPos_X(pos_x -= 0.00003f);
    }

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
       // activeModel->setPos_X(pos_x += 0.00003f);
    }

    //z-axis
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
      //  activeModel->setTheta_Z(theta_z + 0.03f);
        activeModel->setPos_X(pos_x - 0.003f);
    }

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
      //  activeModel->setTheta_Z(theta_z - 0.03f);
      //  activeModel->setTheta_Z(theta_z + 0.03f);
       // activeModel->setPos_X(pos_y + 0.003f);
    }

 //   if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
   //     activeModel->setTheta_Z(theta_z + 0.03f);
  //  }

   // if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
    //    activeModel->setTheta_Z(theta_z - 0.03f);
  //  }

    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
      //  activeModel->setTheta_X(theta_x + 0.03f);
    }

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
       // activeModel->setTheta_X(theta_x - 0.03f);
    }
    */


    //TESTING
    float theta_x = activeModel->getTheta_X();
    float theta_y = activeModel->getTheta_Y();
    float theta_z = activeModel->getTheta_Z();

    //---------ROTATION----------
    //x-axis
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        activeModel->setTheta_X(theta_x + 0.3f);

    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        activeModel->setTheta_X(theta_x - 0.3f);
    }

    //y-axis
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        activeModel->setTheta_Y(theta_y - 0.3f);
    }

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        activeModel->setTheta_Y(theta_y + 0.3f);
    }

    //z-axis
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        activeModel->setTheta_Z(theta_z + 0.3f);
    }

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        activeModel->setTheta_Z(theta_z - 0.3f);
    }

}




void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode) {

    //  glm::vec3 lasCameraPos = Camera.getCameraPos();
    //  glm::vec3 lastCameraFront = Camera.getCameraFront();
     // glm::vec3 lastCameraUp = Camera.getCameraUp();

      //-------EXIT BUTTON-----------
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    //-------SWAP OBJECTS----------
  /*  if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        if (modelInt == 1) {  //change to light source
            modelInt = 2;
            lightSource->setModelColor(glm::vec4(0.0f, 1.0f, 0.0f, 1.0f)); //color green
            lightsource->setLightColor(glm::vec3(0.0f, 1.0f, 0.0f));
        }

        else {              //change to model
            modelInt = 1;
            lightSource->setModelColor(glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));   //color white
            lightsource->setLightColor(glm::vec3(1.0f, 1.0f, 1.0f));
        }

        std::cout << "Swapped active model" << std::endl;
    }*/

    if (key == GLFW_KEY_1 && action == GLFW_PRESS) {
        if (projectionType == "Perspective")
            std::cout << "Already using perspective projection" << std::endl;
        else {
            //Camera->setCameraPos(lastCameraPos);
            //Camera->setCameraFront(lastCameraFront);
            projectionType = "Perspective";
            i = 0;
            std::cout << "Changed projection type" << std::endl;
        }
    }

    if (key == GLFW_KEY_2 && action == GLFW_PRESS) {
        if (projectionType == "Ortho")
            std::cout << "Already using ortho projection" << std::endl;
        else {
            //lastCameraPos = Camera->getCameraPos();
            //lastCameraFront = Camera->getCameraFront();
            //lastCameraUp = Camera.getCameraUp();
            projectionType = "Ortho";
            i = 1;
            std::cout << "Changed projection type" << std::endl;
        }
    }
}


int main(void) {
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Legaspi,Andrea and Austria,Joshua", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    //mouse callbacks
    glfwSetCursorPosCallback(window, mouse_callback);
    // glfwSetKeyCallback(window, Key_Callback);
    // glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0, 0, width, height);
   



    //--------------SHADER------------------
    Shader* shader = new Shader();
    GLuint shaderProg = shader->createShader("Shaders/model.vert", "Shaders/model.frag");
    glLinkProgram(shaderProg);
    shader->deleteShader();
    


    //--------------PLAYER------------------
    //source: https://github.com/ThiagoPereiraUFV/Submarine-Simulator/blob/master/models/submarine.obj
            //https://github.com/ThiagoPereiraUFV/Submarine-Simulator/blob/master/models/texture/ship.bmp 
            
    //LOAD TEXTURE AND NORMAL MAPS
    GLuint ptexture = psub->loadTexture(1, 1, "3D/player/player_base.png");
    GLuint pNorm_tex = psub->loadNormalMap(1, 2, "3D/player/player_normal.png");

    //VERTEX DATA
    std::vector<GLfloat> pfullVertexData = psub->loadModel("3D/player/pship.obj");
  
    //BIND BUFFERS   
    GLuint pVAO, pVBO;
    psub->bindBuffers(pfullVertexData, &pVAO, &pVBO);
    std::cout << "player model loaded" << std::endl;

    

    //--------------ENEMY 1-----------------
    //source: https://www.cgtrader.com/free-3d-models/military/military-vehicle/submarine-0a98eb1b-a71d-45b9-8ed6-66640987efb6
    GLuint e1texture = esub1->loadTexture(1, 1, "3D/enemy1/enemy1_base.jpg");
    GLuint e1Norm_tex = esub1->loadNormalMap(1, 2, "3D/enemy1/enemy1_normal.png");
    std::vector<GLfloat> e1fullVertexData = esub1->loadModel("3D/enemy1/enemy1.obj");

    GLuint e1VAO, e1VBO;
    esub1->bindBuffers(e1fullVertexData, &e1VAO, &e1VBO);
    std::cout << "enemy1 model loaded" << std::endl;



    //--------------ENEMY 2-----------------
    //source: https://www.cgtrader.com/3d-model/bathyscaphe-c
    GLuint e2texture = esub2->loadTexture(1, 1, "3D/enemy2/enemy2_base.png");
    GLuint e2Norm_tex = esub2->loadNormalMap(1, 1, "3D/enemy2/enemy2_normal.png");
    std::vector<GLfloat> e2fullVertexData = esub2->loadModel("3D/enemy2/enemy2.obj");

    GLuint e2VAO, e2VBO;
    esub2->bindBuffers(e2fullVertexData, &e2VAO, &e2VBO);
    std::cout << "enemy2 model loaded" << std::endl;



    //--------------ENEMY 3-----------------
    //souce: https://www.cgtrader.com/3d-model/fantastic-boat
    GLuint e3texture = esub3->loadTexture(1, 1, "3D/enemy3/enemy3_base.png");
    GLuint e3Norm_tex = esub3->loadNormalMap(1, 1, "3D/enemy3/enemy3_normal.png");
    std::vector<GLfloat> e3fullVertexData = esub3->loadModel("3D/enemy3/enemy3.obj");

    GLuint e3VAO, e3VBO;
    esub3->bindBuffers(e3fullVertexData, &e3VAO, &e3VBO);
    std::cout << "enemy3 model loaded" << std::endl;



    //--------------ENEMY 4-----------------
    //souce: 
    GLuint e4texture = esub4->loadTexture(1, 1, "3D/enemy4/enemy4_base.png");
    GLuint e4Norm_tex = esub4->loadNormalMap(1, 2, "3D/enemy4/enemy4_normal.png");
    std::vector<GLfloat> e4fullVertexData = esub4->loadModel("3D/enemy4/enemy4.obj");

    GLuint e4VAO, e4VBO;
    esub4->bindBuffers(e4fullVertexData, &e4VAO, &e4VBO);
    std::cout << "enemy4 model loaded" << std::endl;




    //--------------ENEMY 5-----------------
    //source: https://www.turbosquid.com/3d-models/3d-titan-submersible-2087088
    GLuint e5texture = esub5->loadTexture(1, 1, "3D/enemy5/enemy5_base.png");
    GLuint e5Norm_tex = esub5->loadNormalMap(1, 2, "3D/enemy5/enemy5_normal.png");
    std::vector<GLfloat> e5fullVertexData = esub5->loadModel("3D/enemy5/enemy5.obj");

    GLuint e5VAO, e5VBO;
    esub5->bindBuffers(e5fullVertexData, &e5VAO, &e5VBO);
    std::cout << "enemy5 model loaded" << std::endl;
   


    //--------------ENEMY 6-----------------
    //source: https://free3d.com/3d-model/tugboat-v1--395993.html
    GLuint e6texture = esub6->loadTexture(1, 1, "3D/enemy6/enemy6_base.png");
    GLuint e6Norm_tex = esub6->loadNormalMap(1, 1, "3D/enemy6/enemy6_normal.png");
    std::vector<GLfloat> e6fullVertexData = esub6->loadModel("3D/enemy6/enemy6.obj");

    GLuint e6VAO, e6VBO;
    esub6->bindBuffers(e6fullVertexData, &e6VAO, &e6VBO);
    std::cout << "enemy6 model loaded" << std::endl;


    //--------------SKYBOX------------------
    Shader* skybox_shader = new Shader();
    GLuint skybox_shaderProg = skybox_shader->createShader("Shaders/sky.vert", "Shaders/sky.frag");
    glLinkProgram(skybox_shaderProg);
    skybox_shader->deleteShader();

    Skybox* skybox = new Skybox();

    unsigned int skyboxVAO;
    skybox->bindBuffers(&skyboxVAO);

    std::string facesSkybox[]{
        "Skybox/ocean_rt.png",
        "Skybox/ocean_lf.png",
        "Skybox/ocean_up.png",
        "Skybox/ocean_dn.png",
        "Skybox/ocean_ft.png",
        "Skybox/ocean_bk.png"
    };

    unsigned int skyboxTex = skybox->initializeCubeMap(facesSkybox);



   // PointLight pointLight;
    //spawn model on run
 //   spawnModel();a



    //BLENDING
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, //source factor
        GL_ONE_MINUS_SRC_ALPHA); //destination factor)






    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //per-frame time logic
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        //input
        processInput(window);
        glfwSetKeyCallback(window, Key_Callback);

        glm::mat4 viewMatrix = glm::mat4(1.0f);
        glm::mat4 projection = glm::mat4(1.0f);


        if (projectionType == "Perspective") {
            PerspectiveCamera perspective;
            projection = perspective.giveProjection(width, height);
            Camera->bindProjection(shaderProg, projection);
            viewMatrix = Camera->bindView(shaderProg);
        }
        else if (projectionType == "Ortho") {
            OrthoCamera ortho;
            projection = ortho.giveProjection();
            Camera->bindProjection(shaderProg, projection);
            viewMatrix = ortho.bindView(shaderProg);
        }


        //LIGHTING
      //  directionLight->setLightPos(glm::vec3(0.0, 5.0f, 1.0f));
       // directionLight->setUpProperties();
        directionLight->bindLightDirection(shaderProg);
        directionLight->bindLighting(shaderProg);


        //--------------DRAW SKYBOX---------------
        skybox->drawSkybox(skybox_shaderProg, &skyboxVAO, viewMatrix, projection, skyboxTex);

        


        glm::vec3 lightPosition = lightSource->getPosition();
      //d  pointLight.setLightPoint(lightPosition);
     //   DirectionLight dirLight;
       // dirLight.bindLightDirection(psub_shaderProg);

     //   Light light;
     //   light.bindLighting(psub_shaderProg);

    //    pointLight.bindLightPoint(lshaderProg);



        //--------------DRAW MODELS---------------
        psub->drawModel(pfullVertexData, ptexture, pNorm_tex, shaderProg, &pVAO, 8);

        esub1->setScale(glm::vec3(.05f, .05f, .05f));
        esub1->setPosition(glm::vec3(.3f, .3f, .3f));
        esub1->drawModel(e1fullVertexData, e1texture, e1Norm_tex, shaderProg, &e1VAO, 8);

        esub2->setScale(glm::vec3(.05f, .05f, .05f));
        esub2->setPosition(glm::vec3(-0.5f, -0.5f, .5f));
        esub2->drawModel(e2fullVertexData, e2texture, e2Norm_tex, shaderProg, &e2VAO, 8);
      
        esub3->setScale(glm::vec3(.007f, .007f, .007f));
        esub3->setPosition(glm::vec3(-0.2f, -0.2f, .2f));
        esub3->drawModel(e3fullVertexData, e3texture, e3Norm_tex, shaderProg, &e3VAO, 8);

        esub4->setScale(glm::vec3(.07f, .07f, .07f));
        esub4->setPosition(glm::vec3(-0.8f, -0.8f, .8f));
        esub4->drawModel(e4fullVertexData, e4texture, e4Norm_tex, shaderProg, &e4VAO, 8);
        
        esub5->setScale(glm::vec3(.09f, .09f, .09f));
        esub5->setPosition(glm::vec3(-0.8f, 0.8f, .7f));
        esub5->drawModel(e5fullVertexData, e5texture, e5Norm_tex, shaderProg, &e5VAO, 8);

        esub6->setScale(glm::vec3(.09f, .09f, .09f));
        esub6->setPosition(glm::vec3(0.4f, -0.4f, .2f));
        esub6->drawModel(e6fullVertexData, e6texture, e6Norm_tex, shaderProg, &e6VAO, 8);



        //swap front and back buffers 
        glfwSwapBuffers(window);

        // Poll for and process events 
        glfwPollEvents();
    }

    //--------------DELETE BUFFERS---------------
    glDeleteVertexArrays(1, &pVAO);
    glDeleteBuffers(1, &pVBO);
    
    glDeleteVertexArrays(1, &e1VAO);
    glDeleteBuffers(1, &e1VBO);

    glDeleteVertexArrays(1, &e2VAO);
    glDeleteBuffers(1, &e2VBO);

    glDeleteVertexArrays(1, &e3VAO);
    glDeleteBuffers(1, &e3VBO);

    glDeleteVertexArrays(1, &e4VAO);
    glDeleteBuffers(1, &e4VBO);

    glDeleteVertexArrays(1, &e5VAO);
    glDeleteBuffers(1, &e5VBO);

    glDeleteVertexArrays(1, &e6VAO);
    glDeleteBuffers(1, &e6VBO);


    glfwTerminate();

    return 0;
}