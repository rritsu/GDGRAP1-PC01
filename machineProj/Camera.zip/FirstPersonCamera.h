#pragma once

#include "Camera.h"
#include "Model3D.h"

class FirstPersonCamera : public Camera {
public:
    FirstPersonCamera(Model3D* target);

    glm::mat4 getViewMatrix() override;
    void processMouseMovement(float xoffset, float yoffset, bool constrainPitch = true) override;
    void processKeyboard(Camera_Movement direction, float deltaTime) override;

private:
    Model3D* target;
};