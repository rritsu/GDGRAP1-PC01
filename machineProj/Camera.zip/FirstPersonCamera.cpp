#include "FirstPersonCamera.h"

FirstPersonCamera::FirstPersonCamera(Model3D* target)
    : Camera(target->getPosition(), glm::vec3(0.0f, 1.0f, 0.0f)), target(target) {}

glm::mat4 FirstPersonCamera::getViewMatrix() {
    return glm::lookAt(position, position + front, up);
}

void FirstPersonCamera::processMouseMovement(float xoffset, float yoffset, bool constrainPitch) {
    xoffset *= mouseSensitivity;
    yoffset *= mouseSensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if (constrainPitch) {
        if (pitch > 89.0f) pitch = 89.0f;
        if (pitch < -89.0f) pitch = -89.0f;
    }

    updateCameraVectors();
}

void FirstPersonCamera::processKeyboard(Camera_Movement direction, float deltaTime) {
    // First person camera does not support keyboard movement
    // Use target's movement instead
}