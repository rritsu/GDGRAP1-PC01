#include "ThirdPersonCamera.h"

ThirdPersonCamera::ThirdPersonCamera(Model3D* target, float distance)
    : Camera(target->getPosition() + glm::vec3(0.0f, 0.0f, distance), glm::vec3(0.0f, 1.0f, 0.0f)), target(target), distance(distance) {}

glm::mat4 ThirdPersonCamera::getViewMatrix() {
    return glm::lookAt(position, target->getPosition(), up);
}

void ThirdPersonCamera::processMouseMovement(float xoffset, float yoffset, bool constrainPitch) {
    xoffset *= mouseSensitivity;
    yoffset *= mouseSensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if (constrainPitch) {
        if (pitch > 89.0f) pitch = 89.0f;
        if (pitch < -89.0f) pitch = -89.0f;
    }

    updateCameraVectors();
}

void ThirdPersonCamera::processKeyboard(Camera_Movement direction, float deltaTime) {
    float velocity = movementSpeed * deltaTime;
    if (direction == Camera_Movement::FORWARD)
        position += front * velocity;
    if (direction == Camera_Movement::BACKWARD)
        position -= front * velocity;
    if (direction == Camera_Movement::LEFT)
        position -= right * velocity;
    if (direction == Camera_Movement::RIGHT)
        position += right * velocity;
}