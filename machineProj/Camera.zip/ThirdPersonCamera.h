#pragma once

#include "Camera.h"
#include "Model3D.h"

class ThirdPersonCamera : public Camera {
public:
    ThirdPersonCamera(Model3D* target, float distance = 5.0f);

    glm::mat4 getViewMatrix() override;
    void processMouseMovement(float xoffset, float yoffset, bool constrainPitch = true) override;
    void processKeyboard(Camera_Movement direction, float deltaTime) override;

private:
    Model3D* target;
    float distance;
};