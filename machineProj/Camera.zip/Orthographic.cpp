#include "OrthographicCamera.h"

OrthographicCamera::OrthographicCamera(float left, float right, float bottom, float top)
    : Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f)) {
    projectionMatrix = glm::ortho(left, right, bottom, top, -1.0f, 1.0f);
}

glm::mat4 OrthographicCamera::getViewMatrix() {
    return glm::lookAt(position, position + front, up);
}

void OrthographicCamera::processMouseMovement(float xoffset, float yoffset, bool constrainPitch) {
    // Orthographic camera does not support mouse movement
}

void OrthographicCamera::processKeyboard(Camera_Movement