#pragma once

#include "Camera.h"

class OrthographicCamera : public Camera {
public:
    OrthographicCamera(float left, float right, float bottom, float top);

    glm::mat4 getViewMatrix() override;
    void processMouseMovement(float xoffset, float yoffset, bool constrainPitch = true) override;
    void processKeyboard(Camera_Movement direction, float deltaTime) override;

private:
    glm::mat4 projectionMatrix;
};