/*
date modified: 02-07-2024 
caught up and updated
*/

#include <string>
#include <iostream>
#include <vector>

#include "Model3D.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

float width = 800.0f;
float height = 800.0f;

float x = 0.0f, y = 0.0f, z = 1.0f;
float scale_x = 1.0f, scale_y = 1.0f, scale_z = 1.0f;
float axis_x = 0.0f, axis_y = 0.0f, axis_z = 0.0f;
float theta_x = 0.0f, theta_y = 0.0f;
float FOV = 60.0f;

float cam_x = 0.0f, cam_y = 0.0f, cam_z = 3.0f;
float center_x = 0.0f, center_y = 0.0f, center_z = 0.0f;

std::vector<Model3D*> models;

//glm::mat4 identity_matrix = glm::mat4(1.0f);

void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{    
    //SPAWN MODEL
    //if conditional cooldown
    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        Model3D* pModel = new Model3D();
        models.push_back(pModel);
        //pModel->test();
    }
    
    //CAKKERA MOVEMENT (im not sure with this one, the commented out ones might be wrong)
    //forward
    if (key == GLFW_KEY_W) { 
      //  cam_z -= 0.1f;
    }

    //backward
    if (key == GLFW_KEY_S) {
        // cam_z += 0.1f;
    }

    //strafe left
    if (key == GLFW_KEY_A) {
        // cam_x -= 0.1f;
    }

    //ROTATE
    //strafe right
    if (key == GLFW_KEY_D) {
       // cam_x += 0.1f;
    }

    if (key == GLFW_KEY_UP) {
        center_y += 0.1f;
    }

    if (key == GLFW_KEY_DOWN) {
        center_y -= 0.1f;
    }

    if (key == GLFW_KEY_LEFT) {
        center_x -= 0.1f;
    }

    if (key == GLFW_KEY_RIGHT) {
        center_x += 0.1f;
    }
}

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Andrea Maxene Legaspi", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;
    vertBuff << vertSrc.rdbuf();
    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();

    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;
    fragBuff << fragSrc.rdbuf();
    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();

    
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0, 0, width, height);

    glfwSetKeyCallback(window, Key_Callback);


    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &v, NULL);
    glCompileShader(vertexShader);

    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, &f, NULL);
    glCompileShader(fragShader);

    GLuint shaderProg = glCreateProgram();
    glAttachShader(shaderProg, vertexShader);
    glAttachShader(shaderProg, fragShader);

    glLinkProgram(shaderProg);

    std::string path = "3D/Gun.obj";
    std::vector <tinyobj::shape_t> shapes;
    std::vector <tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;

    bool success = tinyobj::LoadObj(&attributes, &shapes, &material, &warning, &error, path.c_str());

    std::vector<GLuint> mesh_indices;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }
   
    GLuint VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    //Currently editing VAO = null
    glBindVertexArray(VAO);
    //Currently editing VAO = VAO

    //Currently editing VBO = null
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Currently editing VBO = VBO
    //VAO <- VBO

    glBufferData(GL_ARRAY_BUFFER, sizeof(GL_FLOAT) * attributes.vertices.size(), &attributes.vertices[0], GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    //glEnableVertexAttribArray(0);
    
    //Currently editing VBO = VBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //Currently editing VBO = EBO

    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * mesh_indices.size(), &mesh_indices[0], GL_STATIC_DRAW);
   
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

   // glBindVertexArray(VAO);


    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {

        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);

//        int size = models.size();
        
        //PROJECTION
        glm::mat4 projection = glm::perspective(
            glm::radians(90.0f),  //FOV
            height / width, //aspect ratio
            0.1f, //near
            100.f // far
        );
        unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        //CAMERA/VIEW
        glm::vec3 cameraPos = glm::vec3(cam_x, 0.0f, cam_z);  //strafe right/left with x //z is for backward and forward(??)
        glm::vec3 WorldUp = glm::vec3(0, 1.0f, 0);  //usually is constant at 0 1 0
        glm::vec3 Center = glm::vec3(center_x, center_y, 0); //for rotating the cam i think...x for right/left, y for up/down(??)

        glm::mat4 viewMatrix = glm::lookAt(cameraPos, Center, WorldUp);

        unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix)); //view Matrix
        
        //draw
        for (int i = 0; i < models.size(); i++) {

            //set each model's position here
            models[i]->setPos_X((i + 1) - 0.8f); //TEMPORARY
           // models[i]->setY((0.0f);
           // models[i]->setZ((1.0f);

            models[i]->drawModel(mesh_indices, shaderProg, &VAO);
        }
    

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}