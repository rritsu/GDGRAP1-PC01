#pragma once

#include "iostream"
#include <vector>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


class Model3D
{
	//attributes/fields
	private:
		float pos_x;
		float pos_y;
		float pos_z;
		float scale_x;
		float scale_y;
		float scale_z;
		float axis_x;
		float axis_y;
		float axis_z;

	//constructor
	public:
		Model3D();

	//methods/behavior
	public:
		void drawModel(std::vector<GLuint> mesh_indices, GLuint shaderProg, GLuint* VAO);
		void setPosition(glm::vec3 newPos);
		void test();

	//getters and setters
	public:
		float getPos_X();
		float getPos_Y();
		float getPos_Z();
		void setPos_X(float pos_x);
		void setPos_Y(float pos_y);
		void setPos_Z(float pos_z);
		float getScale_X();
		float getScale_Y();
		float getScale_Z();
		void setScale_X(float scale_x);
		void setScale_Y(float scale_y);
		void setScale_Z(float scale_z);
		float getAxis_X();
		float getAxis_Y();
		float getAxis_Z();
		void setAxis_X(float axis_x);
		void setAxis_Y(float axis_y);
		void setAxis_Z(float axis_z);
};

